package main

import "fmt"

func main() {
	fmt.Println("Bonjour depuis mon application Go en Docker !")
	fmt.Println("test")
}
